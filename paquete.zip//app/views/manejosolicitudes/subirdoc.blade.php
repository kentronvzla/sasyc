@extends('layouts.master')
@section('contenido')
<div class="panel-heading">
    <div class="panel panel-primary">
        <div class="panel-heading"><strong>Subir Documentos a la Solicitud</strong> 
        </div>
        <div class="panel-body">
            <table class="table">

                <tr>
                    <td>  Fotocopia Cedula -Beneficiario</td>

                    <td>
                        <div class="form-group">

                            <input type="file">
                        </div>   
                    </td>
                </tr>
                <tr>
                    <td> Fotocopia Cedula -Solicitante</td>

                    <td>
                        <div class="form-group">

                            <input type="file">
                        </div>   
                    </td>
                </tr>
                <tr>
                    <td> Carta al Presidente de la republica</td>

                    <td>
                        <div class="form-group">

                            <input type="file">
                        </div>   
                    </td>
                </tr>
                <tr>
                    <td>  Examenes de laboratorio</td>

                    <td>
                        <div class="form-group">

                            <input type="file">
                        </div>   
                    </td>
                </tr>
                <tr>
                    <td>Informe medico</td>

                    <td>
                        <div class="form-group">

                            <input type="file">
                        </div>   
                    </td>

                </tr>
            </table>
        </div>
    </div>
</div> 





@stop