<div class="col-xs-12 col-sm-{{$numCols}} col-md-{{$numCols}}">
    <div class="form-group">
        {{Form::label($params['id'], $params['placeholder'])}}
        <p>{{$attrValue}}</p>
    </div>
</div>