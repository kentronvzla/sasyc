<div class="row">
    <div class="col-lg-12">
        <a href="{{url($url)}}" class="btn btn-primary"><i class="glyphicon glyphicon-plus-sign"></i> Agregar {{$nombre}}</a>
    </div>
</div>