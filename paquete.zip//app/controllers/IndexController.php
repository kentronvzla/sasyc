<?php

class IndexController extends BaseController {

    public function inicio() {
        return View::make('index');
    }

}
