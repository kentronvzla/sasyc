<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Presupuesto
 *
 * @author Nadin Yamani
 */
class Presupuesto extends BaseModel {

    protected $table = "presupuestos";

    /**
     * Campos que se pueden llenar mediante el uso de mass-assignment
     * @link http://laravel.com/docs/eloquent#mass-assignment
     * @var array
     */
    protected $fillable = [
        'solicitud_id', 'requerimiento_id', 'beneficiario_id', 'cantidad', 'monto', 'estatus', 'id_doc_proc', 'id_sol_sum', 'version', 
    ];

    /**
     * Reglas que debe cumplir el objeto al momento de ejecutar el metodo save, 
     * si el modelo no cumple con estas reglas el metodo save retornará false, y los cambios realizados no haran persistencia.
     * @link http://laravel.com/docs/validation#available-validation-rules
     * @var array
     */
    protected $rules = [
        'solicitud_id'=>'required|integer', 
'requerimiento_id'=>'required|integer', 
'beneficiario_id'=>'required|integer', 
'cantidad'=>'required|integer', 
'monto'=>'required', 
'estatus'=>'required', 
'id_doc_proc'=>'integer', 
'id_sol_sum'=>'integer', 
'version'=>'required|integer', 

    ];
    
    protected function getPrettyFields() {
        return [
            'solicitud_id'=>'solicitud_id', 
'requerimiento_id'=>'requerimiento_id', 
'beneficiario_id'=>'beneficiario_id', 
'cantidad'=>'cantidad', 
'monto'=>'monto', 
'estatus'=>'estatus', 
'id_doc_proc'=>'id_doc_proc', 
'id_sol_sum'=>'id_sol_sum', 
'version'=>'version', 

        ];
    }

    public function getPrettyName() {
        return "presupuestos";
    }

    /**
* Define una relación pertenece a Solicitud
* @return Solicitud
*/
public function solicitud(){
    return $this->belongsTo('Solicitud');
}
/**
* Define una relación pertenece a Requerimiento
* @return Requerimiento
*/
public function requerimiento(){
    return $this->belongsTo('Requerimiento');
}
/**
* Define una relación pertenece a Beneficiario
* @return Beneficiario
*/
public function beneficiario(){
    return $this->belongsTo('Beneficiario');
}


}
