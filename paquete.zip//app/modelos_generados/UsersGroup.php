<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of UsersGroup
 *
 * @author Nadin Yamani
 */
class UsersGroup extends BaseModel {

    protected $table = "users_groups";

    /**
     * Campos que se pueden llenar mediante el uso de mass-assignment
     * @link http://laravel.com/docs/eloquent#mass-assignment
     * @var array
     */
    protected $fillable = [
        'user_id', 'group_id', 'VERSION', 
    ];

    /**
     * Reglas que debe cumplir el objeto al momento de ejecutar el metodo save, 
     * si el modelo no cumple con estas reglas el metodo save retornará false, y los cambios realizados no haran persistencia.
     * @link http://laravel.com/docs/validation#available-validation-rules
     * @var array
     */
    protected $rules = [
        'user_id'=>'required|integer', 
'group_id'=>'required|integer', 
'VERSION'=>'required|integer', 

    ];
    
    protected function getPrettyFields() {
        return [
            'user_id'=>'user_id', 
'group_id'=>'group_id', 
'VERSION'=>'VERSION', 

        ];
    }

    public function getPrettyName() {
        return "users_groups";
    }

    /**
* Define una relación pertenece a User
* @return User
*/
public function user(){
    return $this->belongsTo('User');
}
/**
* Define una relación pertenece a Group
* @return Group
*/
public function group(){
    return $this->belongsTo('Group');
}


}
