<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Solicitud
 *
 * @author Nadin Yamani
 */
class Solicitud extends BaseModel {

    protected $table = "solicitudes";

    /**
     * Campos que se pueden llenar mediante el uso de mass-assignment
     * @link http://laravel.com/docs/eloquent#mass-assignment
     * @var array
     */
    protected $fillable = [
        'ano', 'descripcion', 'persona_beneficiario_id', 'persona_solicitante_id', 'area_id', 'referente_id', 'recepcion_id', 'organismo_id', 'ind_mismo_benef', 'ind_inmediata', 'ind_beneficiario_menor', 'actividad', 'referencia', 'accion_tomada', 'necesidad', 'tipo_proc', 'num_proc', 'facturas', 'observaciones', 'moneda', 'prioridad', 'estatus', 'usuario_asignacion_id', 'usuario_autorizacion_id', 'fecha_solicitud', 'fecha_asignacion', 'fecha_aceptacion', 'fecha_aprobacion', 'fecha_cierre', 'tipo_vivienda_id', 'tenencia_id', 'informe_social', 'total_ingresos', 'version', 
    ];

    /**
     * Reglas que debe cumplir el objeto al momento de ejecutar el metodo save, 
     * si el modelo no cumple con estas reglas el metodo save retornará false, y los cambios realizados no haran persistencia.
     * @link http://laravel.com/docs/validation#available-validation-rules
     * @var array
     */
    protected $rules = [
        'ano'=>'required|integer', 
'descripcion'=>'required', 
'persona_beneficiario_id'=>'integer', 
'persona_solicitante_id'=>'integer', 
'area_id'=>'required|integer', 
'referente_id'=>'required|integer', 
'recepcion_id'=>'required|integer', 
'organismo_id'=>'required|integer', 
'ind_mismo_benef'=>'required', 
'ind_inmediata'=>'required', 
'ind_beneficiario_menor'=>'required', 
'actividad'=>'', 
'referencia'=>'', 
'accion_tomada'=>'', 
'necesidad'=>'required', 
'tipo_proc'=>'', 
'num_proc'=>'integer', 
'facturas'=>'', 
'observaciones'=>'', 
'moneda'=>'required', 
'prioridad'=>'required|integer', 
'estatus'=>'required', 
'usuario_asignacion_id'=>'integer', 
'usuario_autorizacion_id'=>'integer', 
'fecha_solicitud'=>'required', 
'fecha_asignacion'=>'', 
'fecha_aceptacion'=>'', 
'fecha_aprobacion'=>'', 
'fecha_cierre'=>'', 
'tipo_vivienda_id'=>'integer', 
'tenencia_id'=>'integer', 
'informe_social'=>'', 
'total_ingresos'=>'', 
'version'=>'integer', 

    ];
    
    protected function getPrettyFields() {
        return [
            'ano'=>'ano', 
'descripcion'=>'descripcion', 
'persona_beneficiario_id'=>'persona_beneficiario_id', 
'persona_solicitante_id'=>'persona_solicitante_id', 
'area_id'=>'area_id', 
'referente_id'=>'referente_id', 
'recepcion_id'=>'recepcion_id', 
'organismo_id'=>'organismo_id', 
'ind_mismo_benef'=>'ind_mismo_benef', 
'ind_inmediata'=>'ind_inmediata', 
'ind_beneficiario_menor'=>'ind_beneficiario_menor', 
'actividad'=>'actividad', 
'referencia'=>'referencia', 
'accion_tomada'=>'accion_tomada', 
'necesidad'=>'necesidad', 
'tipo_proc'=>'tipo_proc', 
'num_proc'=>'num_proc', 
'facturas'=>'facturas', 
'observaciones'=>'observaciones', 
'moneda'=>'moneda', 
'prioridad'=>'prioridad', 
'estatus'=>'estatus', 
'usuario_asignacion_id'=>'usuario_asignacion_id', 
'usuario_autorizacion_id'=>'usuario_autorizacion_id', 
'fecha_solicitud'=>'fecha_solicitud', 
'fecha_asignacion'=>'fecha_asignacion', 
'fecha_aceptacion'=>'fecha_aceptacion', 
'fecha_aprobacion'=>'fecha_aprobacion', 
'fecha_cierre'=>'fecha_cierre', 
'tipo_vivienda_id'=>'tipo_vivienda_id', 
'tenencia_id'=>'tenencia_id', 
'informe_social'=>'informe_social', 
'total_ingresos'=>'total_ingresos', 
'version'=>'version', 

        ];
    }

    public function getPrettyName() {
        return "solicitudes";
    }

    /**
* Define una relación pertenece a PersonaBeneficiario
* @return PersonaBeneficiario
*/
public function personaBeneficiario(){
    return $this->belongsTo('PersonaBeneficiario');
}
/**
* Define una relación pertenece a PersonaSolicitante
* @return PersonaSolicitante
*/
public function personaSolicitante(){
    return $this->belongsTo('PersonaSolicitante');
}
/**
* Define una relación pertenece a Area
* @return Area
*/
public function area(){
    return $this->belongsTo('Area');
}
/**
* Define una relación pertenece a Referente
* @return Referente
*/
public function referente(){
    return $this->belongsTo('Referente');
}
/**
* Define una relación pertenece a Recepcion
* @return Recepcion
*/
public function recepcion(){
    return $this->belongsTo('Recepcion');
}
/**
* Define una relación pertenece a Organismo
* @return Organismo
*/
public function organismo(){
    return $this->belongsTo('Organismo');
}
/**
* Define una relación pertenece a UsuarioAsignacion
* @return UsuarioAsignacion
*/
public function usuarioAsignacion(){
    return $this->belongsTo('UsuarioAsignacion');
}
/**
* Define una relación pertenece a UsuarioAutorizacion
* @return UsuarioAutorizacion
*/
public function usuarioAutorizacion(){
    return $this->belongsTo('UsuarioAutorizacion');
}
/**
* Define una relación pertenece a TipoVivienda
* @return TipoVivienda
*/
public function tipoVivienda(){
    return $this->belongsTo('TipoVivienda');
}
/**
* Define una relación pertenece a Tenencia
* @return Tenencia
*/
public function tenencia(){
    return $this->belongsTo('Tenencia');
}


}
