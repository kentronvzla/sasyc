<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Requerimiento
 *
 * @author Nadin Yamani
 */
class Requerimiento extends BaseModel {

    protected $table = "requerimientos";

    /**
     * Campos que se pueden llenar mediante el uso de mass-assignment
     * @link http://laravel.com/docs/eloquent#mass-assignment
     * @var array
     */
    protected $fillable = [
        'nombre', 'descripcion', 'cod_item', 'cod_cta', 'tipo_requerimiento_id', 'tipo_ayuda_id', 'version', 
    ];

    /**
     * Reglas que debe cumplir el objeto al momento de ejecutar el metodo save, 
     * si el modelo no cumple con estas reglas el metodo save retornará false, y los cambios realizados no haran persistencia.
     * @link http://laravel.com/docs/validation#available-validation-rules
     * @var array
     */
    protected $rules = [
        'nombre'=>'required', 
'descripcion'=>'required', 
'cod_item'=>'', 
'cod_cta'=>'required', 
'tipo_requerimiento_id'=>'required', 
'tipo_ayuda_id'=>'required|integer', 
'version'=>'required|integer', 

    ];
    
    protected function getPrettyFields() {
        return [
            'nombre'=>'nombre', 
'descripcion'=>'descripcion', 
'cod_item'=>'cod_item', 
'cod_cta'=>'cod_cta', 
'tipo_requerimiento_id'=>'tipo_requerimiento_id', 
'tipo_ayuda_id'=>'tipo_ayuda_id', 
'version'=>'version', 

        ];
    }

    public function getPrettyName() {
        return "requerimientos";
    }

    /**
* Define una relación pertenece a TipoRequerimiento
* @return TipoRequerimiento
*/
public function tipoRequerimiento(){
    return $this->belongsTo('TipoRequerimiento');
}
/**
* Define una relación pertenece a TipoAyuda
* @return TipoAyuda
*/
public function tipoAyuda(){
    return $this->belongsTo('TipoAyuda');
}


}
