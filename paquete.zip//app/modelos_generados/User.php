<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of User
 *
 * @author Nadin Yamani
 */
class User extends BaseModel {

    protected $table = "users";

    /**
     * Campos que se pueden llenar mediante el uso de mass-assignment
     * @link http://laravel.com/docs/eloquent#mass-assignment
     * @var array
     */
    protected $fillable = [
        'email', 'password', 'nombre', 'activated', 'activation_code', 'activated_at', 'last_login', 'persist_code', 'reset_password_code', 
    ];

    /**
     * Reglas que debe cumplir el objeto al momento de ejecutar el metodo save, 
     * si el modelo no cumple con estas reglas el metodo save retornará false, y los cambios realizados no haran persistencia.
     * @link http://laravel.com/docs/validation#available-validation-rules
     * @var array
     */
    protected $rules = [
        'email'=>'required', 
'password'=>'required', 
'nombre'=>'', 
'activated'=>'required', 
'activation_code'=>'', 
'activated_at'=>'', 
'last_login'=>'', 
'persist_code'=>'', 
'reset_password_code'=>'', 

    ];
    
    protected function getPrettyFields() {
        return [
            'email'=>'email', 
'password'=>'password', 
'nombre'=>'nombre', 
'activated'=>'activated', 
'activation_code'=>'activation_code', 
'activated_at'=>'activated_at', 
'last_login'=>'last_login', 
'persist_code'=>'persist_code', 
'reset_password_code'=>'reset_password_code', 

        ];
    }

    public function getPrettyName() {
        return "users";
    }

    

}
