<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of TipoVivienda
 *
 * @author Nadin Yamani
 */
class TipoVivienda extends BaseModel {

    protected $table = "tipo_viviendas";

    /**
     * Campos que se pueden llenar mediante el uso de mass-assignment
     * @link http://laravel.com/docs/eloquent#mass-assignment
     * @var array
     */
    protected $fillable = [
        'nombre', 'version', 
    ];

    /**
     * Reglas que debe cumplir el objeto al momento de ejecutar el metodo save, 
     * si el modelo no cumple con estas reglas el metodo save retornará false, y los cambios realizados no haran persistencia.
     * @link http://laravel.com/docs/validation#available-validation-rules
     * @var array
     */
    protected $rules = [
        'nombre'=>'required', 
'version'=>'required|integer', 

    ];
    
    protected function getPrettyFields() {
        return [
            'nombre'=>'nombre', 
'version'=>'version', 

        ];
    }

    public function getPrettyName() {
        return "tipo_viviendas";
    }

    

}
