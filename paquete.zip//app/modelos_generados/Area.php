<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Area
 *
 * @author Nadin Yamani
 */
class Area extends BaseModel {

    protected $table = "areas";

    /**
     * Campos que se pueden llenar mediante el uso de mass-assignment
     * @link http://laravel.com/docs/eloquent#mass-assignment
     * @var array
     */
    protected $fillable = [
        'nombre', 'descripcion', 'tipo_ayuda_id', 'version', 
    ];

    /**
     * Reglas que debe cumplir el objeto al momento de ejecutar el metodo save, 
     * si el modelo no cumple con estas reglas el metodo save retornará false, y los cambios realizados no haran persistencia.
     * @link http://laravel.com/docs/validation#available-validation-rules
     * @var array
     */
    protected $rules = [
        'nombre'=>'required', 
'descripcion'=>'required', 
'tipo_ayuda_id'=>'required|integer', 
'version'=>'required|integer', 

    ];
    
    protected function getPrettyFields() {
        return [
            'nombre'=>'nombre', 
'descripcion'=>'descripcion', 
'tipo_ayuda_id'=>'tipo_ayuda_id', 
'version'=>'version', 

        ];
    }

    public function getPrettyName() {
        return "areas";
    }

    /**
* Define una relación pertenece a TipoAyuda
* @return TipoAyuda
*/
public function tipoAyuda(){
    return $this->belongsTo('TipoAyuda');
}


}
