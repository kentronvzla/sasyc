<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Throttle
 *
 * @author Nadin Yamani
 */
class Throttle extends BaseModel {

    protected $table = "throttle";

    /**
     * Campos que se pueden llenar mediante el uso de mass-assignment
     * @link http://laravel.com/docs/eloquent#mass-assignment
     * @var array
     */
    protected $fillable = [
        'user_id', 'ip_address', 'attempts', 'suspended', 'banned', 'last_attempt_at', 'suspended_at', 'banned_at', 
    ];

    /**
     * Reglas que debe cumplir el objeto al momento de ejecutar el metodo save, 
     * si el modelo no cumple con estas reglas el metodo save retornará false, y los cambios realizados no haran persistencia.
     * @link http://laravel.com/docs/validation#available-validation-rules
     * @var array
     */
    protected $rules = [
        'user_id'=>'integer', 
'ip_address'=>'', 
'attempts'=>'required|integer', 
'suspended'=>'required', 
'banned'=>'required', 
'last_attempt_at'=>'', 
'suspended_at'=>'', 
'banned_at'=>'', 

    ];
    
    protected function getPrettyFields() {
        return [
            'user_id'=>'user_id', 
'ip_address'=>'ip_address', 
'attempts'=>'attempts', 
'suspended'=>'suspended', 
'banned'=>'banned', 
'last_attempt_at'=>'last_attempt_at', 
'suspended_at'=>'suspended_at', 
'banned_at'=>'banned_at', 

        ];
    }

    public function getPrettyName() {
        return "throttle";
    }

    /**
* Define una relación pertenece a User
* @return User
*/
public function user(){
    return $this->belongsTo('User');
}


}
