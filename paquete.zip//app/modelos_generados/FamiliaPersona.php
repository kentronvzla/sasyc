<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of FamiliaPersona
 *
 * @author Nadin Yamani
 */
class FamiliaPersona extends BaseModel {

    protected $table = "familia_persona";

    /**
     * Campos que se pueden llenar mediante el uso de mass-assignment
     * @link http://laravel.com/docs/eloquent#mass-assignment
     * @var array
     */
    protected $fillable = [
        'persona_familia_id', 'persona_beneficiario_id', 'parentesco_id', 
    ];

    /**
     * Reglas que debe cumplir el objeto al momento de ejecutar el metodo save, 
     * si el modelo no cumple con estas reglas el metodo save retornará false, y los cambios realizados no haran persistencia.
     * @link http://laravel.com/docs/validation#available-validation-rules
     * @var array
     */
    protected $rules = [
        'persona_familia_id'=>'required|integer', 
'persona_beneficiario_id'=>'required|integer', 
'parentesco_id'=>'required|integer', 

    ];
    
    protected function getPrettyFields() {
        return [
            'persona_familia_id'=>'persona_familia_id', 
'persona_beneficiario_id'=>'persona_beneficiario_id', 
'parentesco_id'=>'parentesco_id', 

        ];
    }

    public function getPrettyName() {
        return "familia_persona";
    }

    /**
* Define una relación pertenece a PersonaFamilia
* @return PersonaFamilia
*/
public function personaFamilia(){
    return $this->belongsTo('PersonaFamilia');
}
/**
* Define una relación pertenece a PersonaBeneficiario
* @return PersonaBeneficiario
*/
public function personaBeneficiario(){
    return $this->belongsTo('PersonaBeneficiario');
}
/**
* Define una relación pertenece a Parentesco
* @return Parentesco
*/
public function parentesco(){
    return $this->belongsTo('Parentesco');
}


}
