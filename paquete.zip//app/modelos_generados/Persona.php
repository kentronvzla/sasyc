<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Persona
 *
 * @author Nadin Yamani
 */
class Persona extends BaseModel {

    protected $table = "personas";

    /**
     * Campos que se pueden llenar mediante el uso de mass-assignment
     * @link http://laravel.com/docs/eloquent#mass-assignment
     * @var array
     */
    protected $fillable = [
        'nombre', 'apellido', 'tipo_nacionalidad_id', 'ci', 'sexo', 'estado_civil_id', 'lugar_nacimiento', 'fecha_nacimiento', 'nivel_academico_id', 'parroquia_id', 'ciudad', 'zona_sector', 'calle_avenida', 'apto_casa', 'telefono_fijo', 'telefono_celular', 'telefono_otro', 'email', 'twitter', 'ind_trabaja', 'ocupacion', 'ingreso_mensual', 'observaciones', 'ind_asegurado', 'empresa_seguro', 'cobertura', 'otro_apoyo', 'como_conocio_fps', 'version', 
    ];

    /**
     * Reglas que debe cumplir el objeto al momento de ejecutar el metodo save, 
     * si el modelo no cumple con estas reglas el metodo save retornará false, y los cambios realizados no haran persistencia.
     * @link http://laravel.com/docs/validation#available-validation-rules
     * @var array
     */
    protected $rules = [
        'nombre'=>'required', 
'apellido'=>'required', 
'tipo_nacionalidad_id'=>'integer', 
'ci'=>'integer', 
'sexo'=>'', 
'estado_civil_id'=>'integer', 
'lugar_nacimiento'=>'', 
'fecha_nacimiento'=>'', 
'nivel_academico_id'=>'integer', 
'parroquia_id'=>'integer', 
'ciudad'=>'', 
'zona_sector'=>'', 
'calle_avenida'=>'', 
'apto_casa'=>'', 
'telefono_fijo'=>'', 
'telefono_celular'=>'', 
'telefono_otro'=>'', 
'email'=>'', 
'twitter'=>'', 
'ind_trabaja'=>'required', 
'ocupacion'=>'', 
'ingreso_mensual'=>'', 
'observaciones'=>'', 
'ind_asegurado'=>'required', 
'empresa_seguro'=>'', 
'cobertura'=>'', 
'otro_apoyo'=>'', 
'como_conocio_fps'=>'', 
'version'=>'required|integer', 

    ];
    
    protected function getPrettyFields() {
        return [
            'nombre'=>'nombre', 
'apellido'=>'apellido', 
'tipo_nacionalidad_id'=>'tipo_nacionalidad_id', 
'ci'=>'ci', 
'sexo'=>'sexo', 
'estado_civil_id'=>'estado_civil_id', 
'lugar_nacimiento'=>'lugar_nacimiento', 
'fecha_nacimiento'=>'fecha_nacimiento', 
'nivel_academico_id'=>'nivel_academico_id', 
'parroquia_id'=>'parroquia_id', 
'ciudad'=>'ciudad', 
'zona_sector'=>'zona_sector', 
'calle_avenida'=>'calle_avenida', 
'apto_casa'=>'apto_casa', 
'telefono_fijo'=>'telefono_fijo', 
'telefono_celular'=>'telefono_celular', 
'telefono_otro'=>'telefono_otro', 
'email'=>'email', 
'twitter'=>'twitter', 
'ind_trabaja'=>'ind_trabaja', 
'ocupacion'=>'ocupacion', 
'ingreso_mensual'=>'ingreso_mensual', 
'observaciones'=>'observaciones', 
'ind_asegurado'=>'ind_asegurado', 
'empresa_seguro'=>'empresa_seguro', 
'cobertura'=>'cobertura', 
'otro_apoyo'=>'otro_apoyo', 
'como_conocio_fps'=>'como_conocio_fps', 
'version'=>'version', 

        ];
    }

    public function getPrettyName() {
        return "personas";
    }

    /**
* Define una relación pertenece a TipoNacionalidad
* @return TipoNacionalidad
*/
public function tipoNacionalidad(){
    return $this->belongsTo('TipoNacionalidad');
}
/**
* Define una relación pertenece a EstadoCivil
* @return EstadoCivil
*/
public function estadoCivil(){
    return $this->belongsTo('EstadoCivil');
}
/**
* Define una relación pertenece a NivelAcademico
* @return NivelAcademico
*/
public function nivelAcademico(){
    return $this->belongsTo('NivelAcademico');
}
/**
* Define una relación pertenece a Parroquia
* @return Parroquia
*/
public function parroquia(){
    return $this->belongsTo('Parroquia');
}


}
