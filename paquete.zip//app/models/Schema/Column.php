<?php

namespace SchemaHelper;

/**
 * SchemaHelper\Column
 *
 */
class Column extends \Eloquent {
    
    protected $table = "information_schema.columns";

}
