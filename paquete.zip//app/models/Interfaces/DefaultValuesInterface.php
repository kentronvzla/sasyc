<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author nadinarturo
 */
interface DefaultValuesInterface {

    /**
     * Valores que tomara el objeto por defecto al momento de insertar..
     * @return array Default Values.. 
     */
    function getDefaultValues();

}
